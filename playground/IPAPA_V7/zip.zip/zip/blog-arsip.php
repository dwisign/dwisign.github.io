<!DOCTYPE html>
<html lang="en">
  <head>
    <title>IPAPA V.7 | Blog</title>
    <?php
      require("inc/header.php");
    ?>
    <!-- Ipapa v.7_about style -->
    <link href="css/ipapav7_blog.css" rel="stylesheet">
  </head>
  <body>
    
    <?php
      require("inc/topbar-blog.php");
    ?> 

    <!--content wrap-->
    <div class="content-wrap container ctnr-cstm cntn-inside">

        <div class="row">
          <div class="col-md-8 blog-left">
            <h3 class="title-3 with-hr">2016</h3>
            <div class="list-group list-arsip">
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>Pelaku Startup Asing Minati Sewa Kantor di Bali </p></a>     
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>6 Camilan Sehat di Kantor Yang tak Bikin Gendut</p></a> 
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>Tips Aman Meninggalkan Rumah Saat Mudik </p></a>
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>6 Camilan Sehat di Kantor Yang tak Bikin Gendut </p></a>
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>Pelaku Startup Asing Minati Sewa Kantor di Bali </p></a>     
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>6 Camilan Sehat di Kantor Yang tak Bikin Gendut</p></a> 
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>Tips Aman Meninggalkan Rumah Saat Mudik </p></a>
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>6 Camilan Sehat di Kantor Yang tak Bikin Gendut </p></a>
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>Pelaku Startup Asing Minati Sewa Kantor di Bali </p></a>     
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>6 Camilan Sehat di Kantor Yang tak Bikin Gendut</p></a> 
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>Tips Aman Meninggalkan Rumah Saat Mudik </p></a>
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>6 Camilan Sehat di Kantor Yang tak Bikin Gendut </p></a>
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>Pelaku Startup Asing Minati Sewa Kantor di Bali </p></a>     
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>6 Camilan Sehat di Kantor Yang tak Bikin Gendut</p></a> 
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>Tips Aman Meninggalkan Rumah Saat Mudik </p></a>
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>6 Camilan Sehat di Kantor Yang tak Bikin Gendut </p></a>
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>Pelaku Startup Asing Minati Sewa Kantor di Bali </p></a>     
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>6 Camilan Sehat di Kantor Yang tak Bikin Gendut</p></a> 
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>Tips Aman Meninggalkan Rumah Saat Mudik </p></a>
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>6 Camilan Sehat di Kantor Yang tak Bikin Gendut </p></a>
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>Pelaku Startup Asing Minati Sewa Kantor di Bali </p></a>     
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>6 Camilan Sehat di Kantor Yang tak Bikin Gendut</p></a> 
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>Tips Aman Meninggalkan Rumah Saat Mudik </p></a>
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>6 Camilan Sehat di Kantor Yang tak Bikin Gendut </p></a>
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>Pelaku Startup Asing Minati Sewa Kantor di Bali </p></a>     
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>6 Camilan Sehat di Kantor Yang tak Bikin Gendut</p></a> 
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>Tips Aman Meninggalkan Rumah Saat Mudik </p></a>
              <a href="blog-detail.php" class="list-group-item"><span class="badge">Rabu, 30-08-2017</span> <p>6 Camilan Sehat di Kantor Yang tak Bikin Gendut </p></a>
            </div>
            <br/>
            <div class="text-center">
              <ul class="pagination">
                <li class="disabled"><a href="#">&laquo;</a></li>
                <li class="active"><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">4</a></li>
                <li><a href="#">5</a></li>
                <li><a href="#">&raquo;</a></li>
              </ul>
            </div>

          </div>
          <div class="col-md-4 blog-right">
            <div class="sidebar">
              <div class="white-box-sidebar">
                <h3 class="title-4 with-hr">Kategori</h3>
                <div class="list-white-box"><a href="blog-kategori.php">Bisnis <span class="count-1">(20)</span></a></div>
                <div class="list-white-box"><a href="blog-kategori.php">Interior <span class="count-1">(30)</span></a></div>
                <div class="list-white-box"><a href="blog-kategori.php">kuliner <span class="count-1">(50)</span></a></div>
                <div class="list-white-box"><a href="blog-kategori.php">Internasional <span class="count-1">(40)</span></a></div>
                <div class="list-white-box"><a href="blog-kategori.php">Berita <span class="count-1">(20)</span></a></div>
              </div>
              <div class="white-box-sidebar">
                <h3 class="title-4 with-hr">Arsip</h3>
                <p class="small more-blog"><a href="blog-arsip.php">LIHAT SEMUA <span class="fa fa-angle-right" aria-hidden="true"></span></a></p>
                <div class="list-white-box"><a href="blog-arsip.php">2015 <span class="count-1">(20)</span></a></div>
                <div class="list-white-box"><a href="blog-arsip.php">2016 <span class="count-1">(30)</span></a></div>
                <div class="list-white-box"><a href="blog-arsip.php">2017 <span class="count-1">(50)</span></a></div>
              </div>
              <div class="ad-sidebar">
                <a href="#"><img src="img/downloadAd.jpg" width="100%" class="download-vert"><img src="img/downloadAd-hrz.jpg" width="100%" class="download-hrz"></a>
              </div>
              <div class="sbscrb-sidebar">
                <div class="ico-sbscrb-sidebar">
                  <i class="fa fa-envelope-o" aria-hidden="true"></i>
                </div>
                <h4>Subscribe sekarang !</h4><br/>
                <div class="input-sbscrb-sidebar">
                  <input class="form-control form-rounded form-sbscrb-sidebar" id="inputEmail" placeholder="Email" type="text">
                  <a href="#" class="btn btn-danger btn-rounded btn-sbscrb-sidebar"><i class="fa fa-paper-plane" aria-hidden="true"></i></a>
                </div>
                <br/>
                <p class="small">Dapatkan pemberitahuan dari update kami di email Anda</p>
              </div>
            </div>
          </div>
        </div>
      </div>

    <!--end content wrap-->

    <?php
      require("inc/footer.php");
    ?> 

    <?php  
      require("inc/js.php");
    ?>
 
  </body>
</html>