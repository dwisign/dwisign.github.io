<!DOCTYPE html>
<html lang="en">
  <head>
    <title>IPAPA V.7 | Klien</title>
    <?php
      require("inc/header.php");
    ?>
    <!-- Ipapa v.7_faq style -->
    <link href="css/ipapav7_faq.css" rel="stylesheet">
  </head>
  <body>
    
    <?php
      require("inc/topbar.php");
    ?> 

    <!--content wrap-->
    <div class="content-wrap container ctnr-cstm cntn-inside">
      <h3 class="title-1 with-hr">Klien</h3>


    </div>
    <!--end content wrap-->

    <?php
      require("inc/footer.php");
    ?> 

    <?php  
      require("inc/js.php");
    ?> 
  </body>
</html>