<div class="footer">
	<div class="container ctnr-cstm">
		<div class="row">
			<div class="col-sm-3 footer-col">
				<img src="img/logo-ipapa.png" width="150"><br/><br/>
				<img src="img/logo-zmg.png" width="85">
			</div>
			<div class="col-sm-3 footer-col">
				<h5 class="footer-title">QUICK LINKS</h5>
				<p><a href="disclaimer.php">Disclaimer</a></p>
				<p><a href="privacy-policy.php">Privacy Policy</a></p>
				<p><a href="term-of-use.php">Term Of Use</a></p>
				<p><a href="copyrights.php">Copyrights</a></p>
			</div>
			<div class="col-sm-3 footer-col">
				<h5 class="footer-title">.</h5>
				<p><a href="about.php">Profil</a></p>
				<p><a href="career.php">IPAPA Karir</a></p>
				<p><a href="faq.php">FAQ</a></p>
				<p><a href="#">Site Map</a></p>
			</div>
			<div class="col-sm-3 footer-col">
				<h5 class="footer-title">SOSIAL MEDIA</h5>
				<a href="#"><img src="img/fb.png"></a>
				<a href="#"><img src="img/tw.png"></a>
				<a href="#"><img src="img/in.png"></a>
				<a href="#"><img src="img/ig.png"></a>
				<a href="#"><img src="img/gp.png"></a>
			</div>
		</div>
		<div class="bldg-orn">
			<img src="img/building-ornament.png">
		</div>
	</div>
</div>
<div class="copyright">
	<p>© 2017 IPAPA Indonesia</p>
</div>